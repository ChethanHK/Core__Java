package corejava.info;

public class CompositeValue1 {

	int marks;
	int size;
	
	public CompositeValue1(int marks, int size) {

		this.marks = marks;
		this.size = size;
	}
	
	
}
