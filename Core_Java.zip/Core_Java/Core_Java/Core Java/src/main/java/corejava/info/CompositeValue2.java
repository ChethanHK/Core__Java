package corejava.info;

public class CompositeValue2 {

	float testscore;
	float labscore;
	float quizscore;
	float projectscore;
	float overallScore;
	
	public CompositeValue2(float testscore2, float labscore2, float quizscore2, float projectscore2, float overallScore2) {
		this.testscore = testscore2;
		this.labscore = labscore2;
		this.quizscore = quizscore2;
		this.projectscore = projectscore2;
		this.overallScore = overallScore2;
	}
}
